import React from "react";

const DoctorDashboard = () => {
  return <h1>Welcome to the Doctor Dashboard</h1>;
};

export default DoctorDashboard;