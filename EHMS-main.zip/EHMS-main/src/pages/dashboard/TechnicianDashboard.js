import React from "react";

const TechnicianDashboard = () => {
  return <h1>Welcome to the Technician Dashboard</h1>;
};

export default TechnicianDashboard;